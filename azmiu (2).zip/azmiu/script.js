$(document).ready(function () {
  $(".tab-carousel").owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    autoplay: true,
    dots: true,
    responsive: {
      0: {
        items: 1,
      },
    },
  });
  $(".side-carousel").owlCarousel({
    loop: true,
    margin: 10,
    autoplay: true,
    animateOut: "fadeOut",
    animateIn: "fadeIn",
    nav: false,
    dots: true,
    responsive: {
      0: {
        items: 1,
      },
    },
  });
  $(".logo-link .owl-carousel").owlCarousel({
    loop: true,
    margin: 20,
    nav: true,
    autoplay: true,
    dots: false,
    navText: [
      "<i class='fa fa-chevron-left'></i>",
      "<i class='fa fa-chevron-right'></i>",
    ],
    responsive: {
      0: {
        items: 1,
      },
      500: {
        items: 3,
      },
      767: {
        items: 5,
      },
    },
  });
  $("#gallery").unitegallery({
    theme_enable_text_panel: false,
    slider_scale_mode: "down",
  });
  $(".sandbox-container div").datepicker();
  $(".footer-contact-form .radio-btn").on("click", function () {
    $(".footer-contact-form .radio-btn").removeClass("active");
    $(this).addClass("active");
    $(this).parent().parent().collapse("hide");
  });
  $(".search-btn").on("click", function () {
    $("body").addClass("search-open");
  });
});
$(window).on("load", function () {
  $("#defaultModal").modal("hide");
});
